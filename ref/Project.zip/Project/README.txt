Code structure
sw/: 	Reference software
hw/:	Hardware code
	cnn_accel/		Code for the three-layer network (espcn)
	cnn_accel_ssai2021/	Code for the eight-layer network (ssai2021)
	cnn_accel_opt/		Code for optimization	